import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import psycopg2
from pandas import DataFrame
from PIL import Image

# Connexion PostgreSQL portable
DB_HOST = 'localhost'
DB_PORT = '5432'
DB_NAME = 'postgres'
DB_USER = 'postgres'

def connect_db():
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            dbname=DB_NAME,
            user=DB_USER
        )
        return conn
    except Exception as e:
        st.error(f"Erreur de connexion : {e}")
        return None
    
def table_wrk_decklists(conn):
    cur = conn.cursor()
    query=cur.execute('Select * From wrk_decklists;')
    rows=cur.fetchall()
    cur.execute("Select COLUMN_NAME from information_schema.columns where table_name = 'wrk_decklists'")
    names = cur.fetchall()
    names_l = []
    for l in names:
        names_l.append(l[0])
    bdd = pd.DataFrame(rows)
    bdd.columns = names_l
    return bdd 
    
def table_temp_decklist(bdd):
    st.write("Aperçu de la table decklists :")
    st.dataframe(bdd.head(10))

def nb_tournois(bdd):
    nb_tournois = bdd["tournament_id"].unique()
    st.write(f"Nombre de tournois: {len(nb_tournois)}")
    


# Main app
def main():
    conn = connect_db()
    if conn:
        st.success("Connexion réussie à PostgreSQL Portable !")
        cur = conn.cursor()
        cur.execute("SELECT version();")
        bdd = table_wrk_decklists(conn)
        table_temp_decklist(bdd)
        nb_tournois(bdd)
        cur.close()
        conn.close()

# Configuration de la page
st.set_page_config(
    page_title="Pokémon TCG Pocket",
    page_icon="🃏",
    layout="wide"
)

# Style CSS simple pour améliorer la présentation
st.markdown("""
    <style>
    .stApp {
        background: linear-gradient(#c9def4, #dfd5e4, #f5ccd4);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #333333;
    }
    h1, h2, h3 {
        color: #EF5350; /* rouge Pokémon */
        font-weight: 700;
    }
    .description {
        font-size: 18px;
        line-height: 1.6;
        margin-bottom: 20px;
    }
    .footer {
        text-align: center;
        color: gray;
        font-size: 14px;
        margin-top: 50px;
    }
    
    /* Sélecteur CSS pour la sidebar */
    [data-testid="stSidebar"] {
        background-color: #edf2fb !important;  
        color: black !important;
    }
    
    /* Chaque onglet (la "case" avec le titre) */
    [data-testid="stTab"] {
        background-color: none;
        color: black ;
        padding: 12px 26px !important;
        border-radius: 10px !important;
        font-weight: 700 !important;
        font-size: 16px !important;
    }
    
    [aria-selected="true"] {
        background-color: #EF5350 !important;
        color: white !important;
        border: #EF5350 !important;
    }
    
    [data-baseweb="tab-highlight"] {
        background-color: #C3C6D7 !important;
    }
            
    /* Cible le conteneur metric principal */
    div[data-testid="stMetric"] {
        background-color: #f5f5f5;
        padding: 10px;
        border-radius: 10px;
        text-align: center;
    }

    /* Cible le label du metric */
    div[data-testid="stMetricLabel"] >  {
        font-size: 22px;
    }

    /* Cible la valeur du metric*/
    div[data-testid="stMetricValue"] > div:nth-child(1) {
        font-size: 40px;
        font-weight: bold;
    }
    </style>
""", unsafe_allow_html=True)


# Interface principale
def head():
    st.title("Pokémon TCG Pocket")
    st.markdown("Par Sergina Bakala, Kiran Derennes, Ifig Le Gonidec, Mattéo Rouanne ")
head()

def layout():
    st.sidebar.title("Filtres")
    st.sidebar.markdown("## Tournois")
    st.sidebar.slider("Nombre de joueur", 0, 100, key="slider_nb_joueur")
    st.sidebar.multiselect("Nom de tournois", ["little-league-legends-1", "16465131fesf6354", "w4r5h8ig5z9gy"], key="multiselect_nom_tournois")
    st.sidebar.markdown("## Decks")
    choix_type = st.sidebar.radio("Type de deck", ["colorless", "water", "fire", "grass", "fighting", "electric", "psychic", "steel", "dark", "dragon"], key="type_deck")
    st.sidebar.select_slider("Win-Rate", ["<30%", "30-50%", "50-80%", ">80%", "Peu importe"], key="select_slider_winrate")
    
    return choix_type
choix_type = layout()

def Presentation():
    col1, col2, col3 = st.columns([1,2,1])
    with col2:
        st.image(
            "GALqQYXtpbYyZRsX5ftVNdSCoN1980aiWtrBahZr.jpg",
            caption="Pokémon TCG Pocket",
            width=800,
        )
    
    # Description du jeu
    st.markdown("""
    <div class="description">
    Pokémon Trading Card Game Pocket (souvent abrégé en Pokémon TCG Pocket) est une adaptation mobile gratuite du jeu de cartes à collectionner Pokémon (TCG), développée par Creatures Inc. et DeNA, et publiée par The Pokémon Company.

    Dans ce jeu, les joueurs construisent des decks composés d’ensembles de cartes et s’affrontent en ligne.
    </div>
    """, unsafe_allow_html=True)
    
    # Fonctionnalités clés
    st.subheader("Objectif")
    st.markdown("""
    Vous avez été mandaté par votre client pour réaliser une analyse du métagame de ce jeu. Votre client souhaite savoir quelles cartes ont le taux de victoire le plus élevé, quelles cartes fonctionnent bien ensemble dans un même deck, quelles cartes utiliser contre les stratégies populaires, si certaines de ces tendances ont évolué depuis le lancement du jeu, ainsi que toute autre information utile que vous pouvez extraire des données. 
    """)
    
    # Appel à l'action
    st.markdown("---")
    st.markdown("### Lien vers l'application")
    st.markdown("[📱 Télécharger sur Google Play](https://play.google.com/store/apps/details?id=com.pokemon.pocket)")
    st.markdown("[🍎 Télécharger sur l'App Store](https://apps.apple.com/app/pokemon-tcgp-pocket/id1563916495)")
    
    # Footer discret
    st.markdown("---")
    st.markdown('<div class="footer">© 2025 Pokémon TCGP Pocket - Application non officielle</div>', unsafe_allow_html=True)

def Strategie():
    st.write("Téma la strat")

def Detail_deck(choix_type):
    option = ["bfsd", "55", "ddg"]
    st.selectbox("Rechercher un deck",option)
    col1, col2, col3= st.columns(3)
    with col1:
        st.image(
                "https://limitlesstcg.nyc3.cdn.digitaloceanspaces.com/pocket/A1a/A1a_017_EN.webp",
                caption="Carte principal du deck",
                width = 300
                
            )
    images_type = {
    "colorless": "colorless_energy_card_vector_symbol_by_biochao_dezrwzj-pre.png",
    "water": "water_energy_card_vector_symbol_by_biochao_dezrx5f-pre.png",
    "fire": "fire_energy_card_vector_symbol_by_biochao_dezrx2m-pre.png",
    "grass": "grass_energy_card_vector_symbol_by_biochao_dezrx3b-pre.png",
    "fighting": "fighting_energy_card_vector_symbol_by_biochao_dezrx1z-pre.png",
    "electric": "electric_energy_card_vector_symbol_by_biochao_dezrx16-pre.png",
    "psychic": "psychic_energy_card_vector_symbol_by_biochao_dezrx4c-pre.png",
    "steel": "steel_energy_card_vector_symbol_by_biochao_dezrx4z-pre.png",
    "dark": "dark_energy_card_vector_symbol_by_biochao_dezrx06-pre.png",
    "dragon": "dragon_energy_card_vector_symbol_by_biochao_dezrx0m-pre.png"
    }
    with col2:
        st.image(
                images_type[choix_type],
                caption="Type du deck",
                width = 300
                
            )
    with col3:
        st.metric("Win-Rate", 0.74)

def onglet():
    tab1, tab2, tab3= st.tabs(["Présentation", "⚔️ Stratégies", "Détails des decks"])
    with tab1: 
        Presentation()
    with tab2: 
        Strategie()
    with tab3:
        Detail_deck(choix_type)


if __name__ == "__main__":
    onglet()
    main()

