import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import psycopg2
from pandas import DataFrame
from PIL import Image

# Connexion PostgreSQL portable
DB_HOST = 'localhost'
DB_PORT = '5432'
DB_NAME = 'postgres'
DB_USER = 'postgres'

# Configuration de la page
st.set_page_config(
    page_title="Pokémon TCG Pocket",
    page_icon="🃏",
    layout="wide"
)

# Style CSS simple pour améliorer la présentation
st.markdown("""
    <style>
    .stApp {
        background: linear-gradient(#c9def4, #dfd5e4, #f5ccd4);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #333333;
    }
    h1, h2, h3 {
        color: #EF5350; /* rouge Pokémon */
        font-weight: 700;
    }
    .description {
        font-size: 18px;
        line-height: 1.6;
        margin-bottom: 20px;
    }
    .footer {
        text-align: center;
        color: gray;
        font-size: 14px;
        margin-top: 50px;
    }
    
    /* Sélecteur CSS pour la sidebar */
    [data-testid="stSidebar"] {
        background-color: #edf2fb !important;  
        color: black !important;
    }
    
    /* Chaque onglet (la "case" avec le titre) */
    [data-testid="stTab"] {
        background-color: none;
        color: black ;
        padding: 12px 26px !important;
        border-radius: 10px !important;
        font-weight: 700 !important;
        font-size: 16px !important;
        }
    
    [aria-selected="true"] {
                background-color: #EF5350 !important;
                color: white !important;
                border: #EF5350 !important;
            }
    
    [data-baseweb="tab-highlight"] {
        background-color: #C3C6D7 !important;}
    </style>
""", unsafe_allow_html=True)
 

def connect_db():
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            dbname=DB_NAME,
            user=DB_USER
        )
        return conn
    except Exception as e:
        st.error(f"Erreur de connexion : {e}")
        return None

# Interface principale
def head():
    st.title("Pokémon TCG Pocket")
    st.markdown("Par Sergina Bakala, Kiran Derennes, Ifig Le Gonidec, Mattéo Rouanne ")

def layout():
    st.sidebar.title("Filtres")
    st.sidebar.write("Infos")
    
def onglet():
    tab1, tab2, tab3= st.tabs(["Présentation", "⚔️ Stratégies", "Détails des decks"])
    with tab1: 
        Presentation()
    with tab2: 
        Detail_deck()
    with tab3:
        Strategie()
def Presentation():
    col1, col2, col3 = st.columns([1,2,1])
    with col2:
        st.image(
            "GALqQYXtpbYyZRsX5ftVNdSCoN1980aiWtrBahZr.jpg",
            caption="Pokémon TCG Pocket",
            width=800,
            
        )
    
    # Description du jeu
    st.markdown("""
    <div class="description">
    Pokémon Trading Card Game Pocket (souvent abrégé en Pokémon TCG Pocket) est une adaptation mobile gratuite du jeu de cartes à collectionner Pokémon (TCG), développée par Creatures Inc. et DeNA, et publiée par The Pokémon Company.

    Dans ce jeu, les joueurs construisent des decks composés d’ensembles de cartes et s’affrontent en ligne.
    </div>
    """, unsafe_allow_html=True)
    
    # Fonctionnalités clés
    st.subheader("Objectif")
    st.markdown("""
    Vous avez été mandaté par votre client pour réaliser une analyse du métagame de ce jeu. Votre client souhaite savoir quelles cartes ont le taux de victoire le plus élevé, quelles cartes fonctionnent bien ensemble dans un même deck, quelles cartes utiliser contre les stratégies populaires, si certaines de ces tendances ont évolué depuis le lancement du jeu, ainsi que toute autre information utile que vous pouvez extraire des données.
    """)
    
    # Appel à l'action
    st.markdown("---")
    st.markdown("### Téléchargez dès maintenant et rejoignez la communauté !")
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("[📱 Télécharger sur Google Play](https://play.google.com/store/apps/details?id=com.pokemon.pocket)")
    with col2:
        st.markdown("[🍎 Télécharger sur l'App Store](https://apps.apple.com/app/pokemon-tcgp-pocket/id1563916495)")
    
    # Footer discret
    st.markdown("---")
    st.markdown('<div class="footer">© 2025 Pokémon TCGP Pocket - Application non officielle</div>', unsafe_allow_html=True)

def Strategie():
    st.pills("Tags", ["Sports", "Politics"])
    st.radio("Pick one", ["cats", "dogs"])
    st.segmented_control("Filter", ["Open", "Closed"])
    st.toggle("Enable")
    st.selectbox("Pick one", ["cats", "dogs"])
    st.multiselect("Buy", ["milk", "apples", "potatoes"])
    st.slider("Pick a number", 0, 100)
    st.select_slider("Pick a size", ["S", "M", "L"])

def Detail_deck():
    option = ["bfsd", "55", "ddg"]
    st.selectbox("Rechercher un deck",option)
    
def table_wrk_decklists(conn):
    cur = conn.cursor()
    query=cur.execute('Select * From wrk_decklists;')
    rows=cur.fetchall()
    conn.commit()
    cur.execute("Select COLUMN_NAME from information_schema.columns where table_name = 'wrk_decklists'")
    names = cur.fetchall()
    names_l = []
    for l in names:
        names_l.append(l[0])
    bdd = pd.DataFrame(rows)
    bdd.columns = names_l
    bdd.head(5)
    return bdd 
    
def table_temp_decklist(bdd):
    bdd
def nb_tournois(bdd):
    nb_tournois = bdd["tournament_id"].unique()
    st.write(f"Nombre de tournois: {len(nb_tournois)}")
    


# Main app
def main():
    conn = connect_db()
    if conn:
        st.success("Connexion réussie à PostgreSQL Portable !")
        cur = conn.cursor()
        cur.execute("SELECT version();")
        bdd = table_wrk_decklists(conn)
        table_temp_decklist(bdd)
        nb_tournois(bdd)
        cur.close()
        conn.close()

head()
layout()
onglet()


if __name__ == "__main__":
    main()
